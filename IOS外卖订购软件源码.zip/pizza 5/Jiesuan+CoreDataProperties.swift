//
//  Jiesuan+CoreDataProperties.swift
//  pizza
//
//  Created by Jiajie on 2020/1/23.
//  Copyright © 2020年 bear. All rights reserved.
//
//

import Foundation
import CoreData


extension Jiesuan {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Jiesuan> {
        return NSFetchRequest<Jiesuan>(entityName: "Jiesuan")
    }

    @NSManaged public var name: String?
    @NSManaged public var price: String?
    @NSManaged public var address: String?

}
