//
//  querenshouhuoViewController.swift
//  pizza
//
//  Created by Jiajie on 2020/1/23.
//  Copyright © 2020年 bear. All rights reserved.
//

import UIKit
import CoreData

class querenshouhuoViewController:   UIViewController,UITableViewDelegate,UITableViewDataSource {
    var myTableView = UITableView()
    var datasource = NSMutableArray()
    var total = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cha()
        myTableView.frame = CGRect.init(x: 0, y: 0, width: ScreenW, height: ScreenH)
        myTableView.delegate=self;
        myTableView.dataSource=self;
        self.view.addSubview(myTableView)
        myTableView.separatorStyle = .none
        myTableView.estimatedRowHeight = 1000;
        myTableView.rowHeight = UITableView.automaticDimension;
        
        myTableView.register(UINib.init(nibName: "jiesuanTableViewCell", bundle: nil), forCellReuseIdentifier: "cell")
        myTableView.separatorStyle = .none
        // Do any additional setup after loading the view.
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datasource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! jiesuanTableViewCell
        var dic = datasource[indexPath.row] as! NSDictionary
        cell.name.text = dic["name"] as! String
        cell.price.text = dic["price"] as! String
        
        return cell
        
    }
    
    //    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    //        return 44
    //    }
    let tf = UITextField()
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let vi = UIView()
        vi.frame = CGRect.init(x: 0, y: 0, width: ScreenW, height: 60)
        vi.backgroundColor = UIColor.white
        let btn = UIButton()
        btn.frame = CGRect.init(x: 0, y: 0, width: ScreenW, height: 60)
        btn.setTitle(NSString.init(format: "total:%d", total) as String, for: UIControl.State.normal)
        btn.addTarget(self, action: #selector(jisuanViewController.dosome), for: UIControl.Event.touchUpInside)
        btn.setTitleColor(UIColor.black, for: UIControl.State.normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 11)
        vi.addSubview(btn)
        
        tf.frame = CGRect.init(x: 0, y: 60, width: ScreenW, height: 60)
        tf.placeholder = "time"
        tf.text = ""
        vi.addSubview(tf)
        
        let btn2 = UIButton()
        btn2.frame = CGRect.init(x: 0, y: 120, width: ScreenW, height: 60)
        btn2.setTitle("Consignee", for: UIControl.State.normal)
        btn2.addTarget(self, action: #selector(jisuanViewController.btnClick), for: UIControl.Event.touchUpInside)
        btn2.setTitleColor(UIColor.black, for: UIControl.State.normal)
        btn2.titleLabel?.font = UIFont.systemFont(ofSize: 11)
        vi.addSubview(btn2)
        return vi
    }
    @objc func dosome(){
    }
    
    func qingkong(){
        // Do any additional setup after loading the view, typically from a nib.
        
        let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        
        let entity = NSEntityDescription.entity(forEntityName: "Jiesuan", in: managedObjectContext)
        
        let request = NSFetchRequest<Jiesuan>(entityName: "Jiesuan")
       
        request.fetchOffset = 0
       
        request.fetchLimit = 10
        
        request.entity = entity
        
        do{
            
            let results:[AnyObject]? = try managedObjectContext.fetch(request)
            
            for user:Jiesuan in results as! [Jiesuan]{
               
                managedObjectContext.delete(user)
            }
            
            try managedObjectContext.save()
       
            
        } catch{
            print("Failed to fetch data.")
        }
        
    }
    @objc func btnClick(){
        
        
        self.qingkong()
        
        
        for i in 0...datasource.count-1 {
            var dic = datasource[i] as! NSDictionary
            let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
            //        通过应用代理对象，获得管理对象上下文
            let managedObjectContext = appDelegate.persistentContainer.viewContext
            //        通过管理对象上下文插入一条实体数据
            let newUser = NSEntityDescription.insertNewObject(forEntityName: "Lishi", into: managedObjectContext) as! Lishi
            
            //        设置实体的用户名,密码属性的内容
            newUser.name = dic["name"] as! String
            newUser.price = dic["price"] as! String
            newUser.time = tf.text
            
            do{
                //          插入实体对象
                try managedObjectContext.save()
                print("Success to save data.")
            } catch{
                print("Failed to save data.")
            }
            
        }
        
        
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 180
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        // Do any additional setup after loading the view, typically from a nib.
        //        获得当前程序的应用代理
        //        var dic = datasource[indexPath.row] as! NSDictionary
        
        
        //
        //        self.cha()
        
    }
    
    func cha() {
        // Do any additional setup after loading the view, typically from a nib.
        //        获得当前程序的应用代理
        let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
        //        通过应用代理对象获得管理对象上下文
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        
        //        通过管理对象上下文，获得实体名称，获得实体对象
        let entity = NSEntityDescription.entity(forEntityName: "Jiesuan", in: managedObjectContext)
        
        //        创建一个数据提取请求对象
        let request = NSFetchRequest<Jiesuan>(entityName: "Jiesuan")
        //        设置提取数据的偏移值
        request.fetchOffset = 0
        //        设置提取数据的数量
        request.fetchLimit = 10
        //        设置需要提取数据的实体对象
        request.entity = entity
        
        //        创建一个谓词对象，设置提取数据的查询条件。谓词被用来指定数据被获取，或者过滤的方式
        //        let predicate = NSPredicate(format: "userName= 'John' ", "")
        //        let predicate = NSPredicate()
        //        //        设置数据提取请求的谓词属性
        //        request.predicate = predicate
        
        do{
            //            执行管理对象上下文数据提取的操作，并存入一个数组
            let results:[AnyObject]? = try managedObjectContext.fetch(request)
            //            对提取结果进行遍历
            for user:Jiesuan in results as! [Jiesuan]{
                let adic = NSMutableDictionary()
                adic.setValue(user.name, forKey: "name")
                adic.setValue(user.price, forKey: "price")
                total = total + NSInteger(user.price!)!
                datasource.add(adic)
                myTableView.reloadData()
                print("name=\(String(describing: user.name))")
                print("price=\(String(describing: user.price))")
            }
        } catch{
            print("Failed to fetch data.")
        }
    }
}
