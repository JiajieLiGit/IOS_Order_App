//
//  dianViewController.swift
//  pizza
//
//  Created by Jiajie on 2020/1/23.
//  Copyright © 2020年 bear. All rights reserved.
//

import UIKit
var ScreenW = UIScreen.main.bounds.size.width
var ScreenH = UIScreen.main.bounds.size.height
class dianViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var myTableView = UITableView()
    var datasource = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
   var dic = NSMutableDictionary()
        dic .setValue("PizzaShop1", forKey: "name")
        dic .setValue("Estimate 10 mins", forKey: "time")
        dic .setValue("Parramatta", forKey: "adress")
        dic .setValue("pz0.jpg", forKey: "image")
datasource.add(dic)
     
        dic = NSMutableDictionary()
        dic .setValue("PizzaShop2", forKey: "name")
        dic .setValue("Estimate 20 mins", forKey: "time")
        dic .setValue("Eastwood", forKey: "adress")
        dic .setValue("pz1.jpg", forKey: "image")
        datasource.add(dic)
        dic = NSMutableDictionary()
        dic .setValue("PizzaShop3", forKey: "name")
        dic .setValue("Estimate 30 mins", forKey: "time")
        dic .setValue("Burwood", forKey: "adress")
        dic .setValue("pz2.jpg", forKey: "image")
        datasource.add(dic)
        dic = NSMutableDictionary()
        dic .setValue("PizzaShop4", forKey: "name")
        dic .setValue("Estimate 40 mins", forKey: "time")
        dic .setValue("Ryde", forKey: "adress")
        dic .setValue("pz3.jpg", forKey: "image")
        datasource.add(dic)
        myTableView.frame = CGRect.init(x: 0, y: 0, width: ScreenW, height: ScreenH)
        myTableView.delegate=self;
        myTableView.dataSource=self;
        self.view.addSubview(myTableView)
        myTableView.separatorStyle = .none
        myTableView.estimatedRowHeight = 1000;
        myTableView.rowHeight = UITableView.automaticDimension;
        
                myTableView.register(UINib.init(nibName: "dianTableViewCell", bundle: nil), forCellReuseIdentifier: "cell")
        myTableView.separatorStyle = .none
        // Do any additional setup after loading the view.
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datasource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! dianTableViewCell
        var dic = datasource[indexPath.row] as! NSDictionary
        cell.name.text = dic["name"] as! String
        cell.time.text = dic["time"] as! String
        cell.img.image=UIImage.init(named: dic["image"] as! String)
        cell.address.text = dic["adress"] as! String
        return cell
        
    }
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 44
//    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let vc = diancaiViewController()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
