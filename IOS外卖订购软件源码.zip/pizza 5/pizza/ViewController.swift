//
//  ViewController.swift
//  pizza
//
//  Created by Jiajie on 2020/1/23.
//  Copyright © 2020年 bear. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var name: UITextField!
    
    @IBAction func login(_ sender: Any) {
        let vc = ViewController1()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)

        if name.text=="admin" {
            if pwd.text == "123456"{
                let vc = ViewController1()
                vc.hidesBottomBarWhenPushed = true
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
    @IBOutlet weak var login: UIButton!
    @IBOutlet weak var pwd: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

