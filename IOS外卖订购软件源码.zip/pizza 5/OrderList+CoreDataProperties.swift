//
//  OrderList+CoreDataProperties.swift
//  pizza
//
//  Created by Jiajie on 2020/1/23.
//  Copyright © 2020年 bear. All rights reserved.
//
//

import Foundation
import CoreData


extension OrderList {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<OrderList> {
        return NSFetchRequest<OrderList>(entityName: "OrderList")
    }

    @NSManaged public var name: String?
    @NSManaged public var price: String?

}
