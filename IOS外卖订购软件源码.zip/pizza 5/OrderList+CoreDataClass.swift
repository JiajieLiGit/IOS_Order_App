//
//  OrderList+CoreDataClass.swift
//  pizza
//
//  Created by Jiajie on 2020/1/23.
//  Copyright © 2020年 bear. All rights reserved.
//
//

import Foundation
import CoreData

@objc(OrderList)
public class OrderList: NSManagedObject {

}
